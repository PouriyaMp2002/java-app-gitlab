# Java Petclinic DevOps Project

A DevOps-focused Java web application project based on the Spring Framework Petclinic application.

The purpose of this repository is to demonstrate a complete CI/CD workflow for building, testing, scanning, containerizing, and deploying a Java application using Maven, Docker, SonarQube, Trivy, GitLab CI/CD, Terraform, AWS ECR, and AWS ECS.

---

## Project Overview

This project contains a Java Spring MVC application packaged as a WAR file and deployed on Apache Tomcat.

The repository also includes DevOps automation for:

- Building and testing a Java Maven application
- Packaging the application as a WAR file
- Running static code analysis with SonarQube
- Scanning artifacts and Docker images with Trivy
- Building a Docker image
- Pushing the Docker image to AWS ECR
- Deploying the application to AWS ECS

The project also includes supporting DevOps setup and infrastructure components: 

- Provisioning infrastructure using Terraform
- Running SonarQube locally using Docker Compose

---

## Repository Structure

```text
.
├── src/                    # Java application source code and tests
├── sonarqube/              # Local SonarQube setup using Docker Compose
├── terraform/              # AWS infrastructure provisioning files
├── Dockerfile              # Docker image definition for Tomcat deployment
├── .gitlab-ci.yml          # CI/CD pipeline definition
├── pom.xml                 # Maven project configuration
├── mvnw                    # Maven wrapper for Linux/macOS
├── mvnw.cmd                # Maven wrapper for Windows
├── .gitignore              # Files and folders ignored by Git
└── README.md               # Project documentation
```

---

## Application Build

The project uses Maven to compile, test, and package the application.

```bash
mvn clean package
```

After a successful build, Maven creates a WAR file inside the `target/` directory:

```text
target/petclinic.war
```

The `target/` folder is generated automatically and should not be pushed to GitHub.

---

## Run the Application with Docker

First build the WAR file:

```bash
mvn clean package
```

Then build the Docker image:

```bash
docker build -t java-app .
```

Run the container:

```bash
docker run -d -p 8080:8080 --name petclinic java-app
```

Open the application:

```text
http://localhost:8080
```

## CI/CD Pipeline Explanation
This project uses a **GitLab CI/CD pipeline** to automate the process of building, checking, containerizing, and deploying the Java application.

When new code is pushed to the repository, the pipeline starts automatically and runs the application through several stages before deployment.

### Pipeline Flow 

```text
Code Push
   ↓
Build Java Application
   ↓
Run Tests
   ↓
Analyze Code with SonarQube
   ↓
Scan Files with Trivy
   ↓
Build Docker Image
   ↓
Scan Docker Image
   ↓
Push Image to AWS ECR
   ↓
Deploy New Version to AWS ECS
```

---

### Build and Test:

The pipeline first uses **Maven** to compile the Java application, run tests, and package the project as a WAR file.

### Code Quality Analysis:

After the build, the pipeline runs **SonarQube analysis** to check the quality of the source code.

SonarQube helps detect:

- Bugs
- Code smells
- Duplicated code
- Maintainability issues
- Possible security problems

If a **quality gate** is configured, the pipeline can stop when the code does not meet the required standard.

### Security Scanning:

The pipeline uses **Trivy** to scan the project files and Docker image for known vulnerabilities.

This adds a **DevSecOps** step before deployment and helps prevent insecure artifacts or container images from being released.

### Docker Image Build: 

After the application passes the quality and security checks, the pipeline builds a Docker image.

The Docker image uses *Apache Tomcat* as the runtime environment and copies the generated *petclinic.war* file into the Tomcat webapps directory as *ROOT.war*.

### Push To Amazon ECR (Elastich Container Registry)

Once the Docker image is built and scanned, it is tagged and pushed to AWS Elastic Container Registry.

ECR stores the Docker image so it can be pulled later by AWS ECS during deployment.

Using image tags, such as the **Git commit SHA or pipeline build number**, makes it possible to track which version of the code is running in each deployment.
